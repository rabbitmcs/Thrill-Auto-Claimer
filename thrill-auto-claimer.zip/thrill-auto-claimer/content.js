// Fallback path: performs the redeem request from inside a thrill.com tab,
// so it looks exactly like the site's own request (same origin + cookies).
const API = "https://api.thrill.com/reward/v2/players/self/cash-drops";

chrome.runtime.onMessage.addListener((m, _sender, send) => {
  if (!m || m.type !== "redeem") return;
  fetch(API, {
    method: "POST",
    credentials: "include",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ code: m.code, currency: m.currency }),
  })
    .then(async (r) => send({ status: r.status, text: await r.text() }))
    .catch((e) => send({ status: 0, error: String(e) }));
  return true; // async response
});
