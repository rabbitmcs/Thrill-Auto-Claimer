const $ = (id) => document.getElementById(id);

function render(s) {
  const status = s.status || "connecting";
  $("st").textContent = status;
  $("status").className = "status " + status;
  $("enabled").checked = s.enabled !== false;
  $("notify").checked = s.notify !== false;
  if (document.activeElement !== $("currency")) $("currency").value = s.currency || "USDT";

  const log = s.log || [];
  const ul = $("log");
  ul.innerHTML = "";
  if (!log.length) {
    ul.innerHTML = '<div class="empty">No codes yet. Waiting for the next drop.</div>';
    return;
  }
  for (const e of log) {
    const li = document.createElement("li");
    const left = document.createElement("div");
    const code = document.createElement("div");
    code.className = "code";
    code.textContent = e.code + (e.value ? "  ($" + e.value + ")" : "");
    const msg = document.createElement("div");
    msg.className = "msg";
    msg.textContent = e.message;
    left.append(code, msg);
    const right = document.createElement("div");
    right.className = e.result;
    right.textContent = e.result === "claimed" ? "Claimed" : e.result === "login" ? "Log in" : "Failed";
    li.append(left, right);
    ul.append(li);
  }
}

const load = () => chrome.storage.local.get(null).then(render);
chrome.storage.onChanged.addListener(load);
load();

$("enabled").onchange = (e) => chrome.storage.local.set({ enabled: e.target.checked });
$("notify").onchange = (e) => chrome.storage.local.set({ notify: e.target.checked });
