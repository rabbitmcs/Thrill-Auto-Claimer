// Thrill Cash Drop Auto-Claimer - background service worker.
// Connects to the relay, and redeems every new code with the user's own
// logged-in thrill.com session. Codes are never sent anywhere else.

const RELAY = "wss://stakecodedrop.com/thrill-ws";
const API = "https://api.thrill.com/reward/v2/players/self/cash-drops";
const MAX_LOG = 40;
const NOT_FOUND_RETRIES = 2; // code posted a hair before Thrill has it live
const RETRY_DELAY_MS = 400;
const REPLAY_WINDOW_MS = 30 * 60 * 1000; // on connect, only replay codes this recent

let ws = null;
let retryMs = 1000;
let keepalive = null;
const seen = new Set();
let ready = null;

// Make requests from the extension look like they come from thrill.com itself.
chrome.declarativeNetRequest.updateSessionRules({
  removeRuleIds: [1],
  addRules: [
    {
      id: 1,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "origin", operation: "set", value: "https://thrill.com" },
          { header: "referer", operation: "set", value: "https://thrill.com/" },
        ],
      },
      condition: {
        urlFilter: "||api.thrill.com/reward/",
        resourceTypes: ["xmlhttprequest"],
        tabIds: [-1],
      },
    },
  ],
});

async function init() {
  const { log = [] } = await chrome.storage.local.get("log");
  log.forEach((e) => seen.add(e.code));
  const { claimed = 0 } = await chrome.storage.local.get("claimed");
  setBadge(claimed);
}
ready = init();

async function settings() {
  return chrome.storage.local.get({ enabled: true, currency: "USDT", notify: true });
}

async function setStatus(state) {
  await chrome.storage.local.set({ status: state });
  if (state !== "connected") {
    chrome.action.setBadgeText({ text: "!" });
    chrome.action.setBadgeBackgroundColor({ color: "#e0913a" });
  } else {
    const { claimed = 0 } = await chrome.storage.local.get("claimed");
    setBadge(claimed);
  }
}

function setBadge(n) {
  chrome.action.setBadgeText({ text: n > 0 ? String(n) : "" });
  chrome.action.setBadgeBackgroundColor({ color: "#2fbf86" });
}

// ---- relay connection --------------------------------------------------
function connect() {
  if (ws && (ws.readyState === WebSocket.CONNECTING || ws.readyState === WebSocket.OPEN)) return;
  let sock;
  try {
    sock = new WebSocket(RELAY);
  } catch {
    return scheduleReconnect();
  }
  ws = sock;
  setStatus("connecting");
  sock.onopen = () => {
    retryMs = 1000;
    setStatus("connected");
    clearInterval(keepalive);
    // an outbound message every 20s keeps the service worker alive
    keepalive = setInterval(() => {
      if (sock.readyState === WebSocket.OPEN) sock.send('{"t":"ping"}');
    }, 20000);
  };
  sock.onmessage = (e) => {
    try {
      onMessage(JSON.parse(e.data));
    } catch {}
  };
  const down = () => {
    if (ws !== sock) return;
    clearInterval(keepalive);
    ws = null;
    setStatus("disconnected");
    scheduleReconnect();
  };
  sock.onclose = down;
  sock.onerror = down;
}

function scheduleReconnect() {
  setTimeout(connect, retryMs);
  retryMs = Math.min(retryMs * 2, 30000);
}

function onMessage(msg) {
  if (msg.type === "code") {
    redeem(msg);
  } else if (msg.type === "hello" && Array.isArray(msg.recent)) {
    for (const rec of msg.recent) {
      const age = Date.now() - Date.parse(rec.posted_at);
      if (age <= REPLAY_WINDOW_MS) redeem(rec);
    }
  }
}

// ---- redeeming ---------------------------------------------------------
async function post(code, currency) {
  try {
    const r = await fetch(API, {
      method: "POST",
      credentials: "include",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ code, currency }),
    });
    return { status: r.status, text: await r.text() };
  } catch (e) {
    return { status: 0, error: String(e) };
  }
}

async function postViaTab(code, currency) {
  const tabs = await chrome.tabs.query({ url: "https://thrill.com/*" });
  for (const t of tabs) {
    try {
      const res = await chrome.tabs.sendMessage(t.id, { type: "redeem", code, currency });
      if (res && res.status) return res;
    } catch {}
  }
  return null;
}

function parse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

async function attempt(code, currency) {
  let r = await post(code, currency);
  if (r.status === 0 || r.status === 401 || r.status === 403) {
    const viaTab = await postViaTab(code, currency);
    if (viaTab) r = viaTab;
  }
  return r;
}

async function redeem(rec) {
  await ready;
  const { enabled, currency, notify } = await settings();
  if (!enabled) return;
  if (rec.valid_till && Date.parse(rec.valid_till) < Date.now()) return;
  if (seen.has(rec.code)) return;
  seen.add(rec.code);

  const t0 = Date.now();
  let r = await attempt(rec.code, currency);
  for (let i = 0; i < NOT_FOUND_RETRIES; i++) {
    if (parse(r.text).errorCode !== "cash_drop_code_not_found_error") break;
    await new Promise((res) => setTimeout(res, RETRY_DELAY_MS));
    r = await attempt(rec.code, currency);
  }
  const ms = Date.now() - t0;
  const body = parse(r.text);
  const ok = r.status >= 200 && r.status < 300;
  const loginNeeded = r.status === 401 || r.status === 403;
  const entry = {
    code: rec.code,
    value: rec.value,
    at: Date.now(),
    ms,
    status: r.status,
    result: ok ? "claimed" : loginNeeded ? "login" : "failed",
    message: ok
      ? body.message || "Claimed"
      : loginNeeded
      ? "Not logged in to thrill.com"
      : body.message || body.errorCode || r.error || "Failed",
  };
  const { log = [] } = await chrome.storage.local.get("log");
  log.unshift(entry);
  log.length = Math.min(log.length, MAX_LOG);
  await chrome.storage.local.set({ log });

  if (ok) {
    const { claimed = 0 } = await chrome.storage.local.get("claimed");
    await chrome.storage.local.set({ claimed: claimed + 1 });
    setBadge(claimed + 1);
  }
  if (notify && (ok || loginNeeded)) {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: ok ? `Claimed ${rec.value ? "$" + rec.value : "cash drop"}` : "Thrill: please log in",
      message: ok ? `Code ${rec.code} redeemed in ${ms} ms` : "Log in at thrill.com to auto-claim codes.",
    });
  }
}

// ---- lifecycle ---------------------------------------------------------
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);
chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(connect);
chrome.storage.onChanged.addListener((changes) => {
  if (changes.enabled && changes.enabled.newValue) connect();
});
connect();
